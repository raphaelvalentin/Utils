from simulator import ngspice

