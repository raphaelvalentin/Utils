
######
SHELL = '/bin/tcsh'
SPECTRE = 'spectre'
CONFIG_ENVIRON = { 5.1:'source /home/cad/Env/.tcshrc.mmsim62', 
                   6.2:'source /home4/dump/tools_temp/cadence/tcshrc.mmsim62', 
	         7.21:'source /home/vraphael/.vraphael/.mmsim72', 
	         7.2:'source /home/cad/.tcshrc.mmsim72', 
	         #10.11:'source /home/cad/Env/.tcshrc.mmsim10',
		 10.11:'/home/vraphael/.vraphael/.tcshrc.mmsim10' }
TEXT_EDITOR = 'nedit'
EXPIRATION = 10
TMP = '/tmp'
PREFIX = 'spectre_'

VERSION = 10.11
HISTORY = 200
