######
SHELL = '/bin/tcsh'
NGSPICE = 'ngspice'
TEXT_EDITOR = 'nedit'
TMP = '/tmp'
PREFIX = 'ngspice_'

