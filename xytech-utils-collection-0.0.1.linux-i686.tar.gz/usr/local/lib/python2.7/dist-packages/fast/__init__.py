from _nearest import nearest1, nearest2, nearest3
